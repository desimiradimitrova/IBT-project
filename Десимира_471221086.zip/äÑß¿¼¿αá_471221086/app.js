const wrapper = document.querySelector(".sliderWrapper"); //
const menuItems = document.querySelectorAll(".menuItem");

const currentProductImg = document.querySelector(".productImg");
const currentProductTitle = document.querySelector(".productTitle");
const currentProductPrice = document.querySelector(".productPrice");
const currentProductColors = document.querySelectorAll(".color");
const currentProductSizes = document.querySelectorAll(".size");

menuItems.forEach((item, index) => {
    item.addEventListener("click", () => {
        //change the current slide
        wrapper.style.transform = `translateX(${-100 * index}vw)`;
    });
});


const productButtons = document.querySelectorAll(".productButton");
const payment = document.querySelector(".payment");
const close = document.querySelector(".close");

productButtons.forEach((button) => {
    button.addEventListener("click", () => {
        payment.style.display = "flex";
        console.log("kliknato!");
    });
});

close.addEventListener("click", () => {
    payment.style.display = "none";
});

